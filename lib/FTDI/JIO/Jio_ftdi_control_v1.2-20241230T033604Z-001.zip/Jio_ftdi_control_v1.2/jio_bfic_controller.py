import argparse
from ftdi_spi_sender import *

en_list = [0,1,2,3]
dis_list = []
header_chain1 = [0xF0, 0x01]
header_chain2 = [0xF0, 0x02]
header_list = [header_chain1, header_chain2]

reg_addr_tx_v = [0x00, 0x03]
reg_addr_rx_v = [0x00, 0x04]
reg_addr_tx_h = [0x00, 0x22]
reg_addr_rx_h = [0x00, 0x23]
reg_addr_list = [reg_addr_tx_h, reg_addr_rx_h, reg_addr_tx_v, reg_addr_rx_v]

dis = 0
com = 15
ele = 0xFFFF

# Boresight phase step with cali phase offset
phase_chain1_ic4 = [0x16, 0x85, 0x46]
phase_chain1_ic3 = [0x1A, 0x69, 0xC7]
phase_chain1_ic2 = [0x1A, 0x8A, 0x46]
phase_chain1_ic1 = [0x02, 0x49, 0x41]
phase_chain2_ic4 = [0x1A, 0x9A, 0xC7]
phase_chain2_ic3 = [0x26, 0x8A, 0x49]
phase_chain2_ic2 = [0x2A, 0x9A, 0x89]
phase_chain2_ic1 = [0x1A, 0x69, 0x85]
phase_tx_v = [
    [phase_chain1_ic4, phase_chain1_ic3, phase_chain1_ic2, phase_chain1_ic1],
    [phase_chain2_ic4, phase_chain2_ic3, phase_chain2_ic2, phase_chain2_ic1]
]
phase_chain1_ic4 = [0x2F, 0x39, 0xCA]
phase_chain1_ic3 = [0x27, 0x2C, 0xCA]
phase_chain1_ic2 = [0x16, 0xBB, 0x05]
phase_chain1_ic1 = [0x02, 0x9A, 0x04]
phase_chain2_ic4 = [0x32, 0xAA, 0xD2]
phase_chain2_ic3 = [0x26, 0xBB, 0x0B]
phase_chain2_ic2 = [0x2E, 0xBB, 0x4C]
phase_chain2_ic1 = [0x26, 0xBA, 0xC9]
phase_rx_v = [
    [phase_chain1_ic4, phase_chain1_ic3, phase_chain1_ic2, phase_chain1_ic1],
    [phase_chain2_ic4, phase_chain2_ic3, phase_chain2_ic2, phase_chain2_ic1]
]
phase_chain1_ic4 = [0x0C, 0x58, 0xCF]
phase_chain1_ic3 = [0x10, 0x49, 0x25]
phase_chain1_ic2 = [0x18, 0x69, 0xA3]
phase_chain1_ic1 = [0x00, 0x08, 0xA6]
phase_chain2_ic4 = [0x10, 0x48, 0x65]
phase_chain2_ic3 = [0x18, 0x53, 0xA4]
phase_chain2_ic2 = [0x1C, 0x79, 0xEC]
phase_chain2_ic1 = [0x00, 0x28, 0xA3]
phase_tx_h = [
    [phase_chain1_ic4, phase_chain1_ic3, phase_chain1_ic2, phase_chain1_ic1],
    [phase_chain2_ic4, phase_chain2_ic3, phase_chain2_ic2, phase_chain2_ic1]
]
phase_chain1_ic4 = [0x28, 0x79, 0xD3]
phase_chain1_ic3 = [0x20, 0x7A, 0x6A]
phase_chain1_ic2 = [0x1C, 0x6A, 0x63]
phase_chain1_ic1 = [0x00, 0x38, 0xA7]
phase_chain2_ic4 = [0x20, 0x89, 0x27]
phase_chain2_ic3 = [0x24, 0x94, 0x68]
phase_chain2_ic2 = [0x24, 0xDA, 0xAE]
phase_chain2_ic1 = [0x0C, 0x6A, 0x68]
phase_rx_h = [
    [phase_chain1_ic4, phase_chain1_ic3, phase_chain1_ic2, phase_chain1_ic1],
    [phase_chain2_ic4, phase_chain2_ic3, phase_chain2_ic2, phase_chain2_ic1]
]
phase_list= [phase_tx_h, phase_rx_h, phase_tx_v, phase_rx_v]


def version():
    return "1.2"

def hex_int_type(value):
    try:
        ret = 0
        if value.startswith("0x"):
            ret = int(value, 16)
        else:
            ret = int(value)
        print("\'%s\' -> hex(int): 0x%03X(%d)" %(value, ret, ret))
        return ret
    except ValueError:
        raise argparse.ArgumentTypeError(f"Invalid hex value: {value}")

def getBficConfig(addr)->bool:
    devA, devB = initialize_ft4222()
    if not devA:
        return False

    for chain_id in range(len(header_list)):
        print(f"Chain-{chain_id+1}")
        # for each chain
        # RADDR
        raddr = 0x03D << 48 | addr & 0x3FF
        raddr = raddr << 60 | raddr
        raddr_bytes = raddr.to_bytes(15, 'big')
        pattern = bytearray(header_list[chain_id]) + bytearray(raddr_bytes) + bytearray(raddr_bytes)
        spi_transfer(devA, devB, pattern)

        # SPARE
        spare = 0x001 << 48
        spare = spare << 60 | spare
        spare_bytes = spare.to_bytes(15, 'big')
        pattern = bytearray(header_list[chain_id]) + bytearray(spare_bytes) + bytearray(spare_bytes)
        spi_transfer(devA, devB, pattern)

    close_ft4222(devA, devB)
    return True

def setBficConfig(dis:bool, pol:int, com:int, ele:int)->bool:
    devA, devB = initialize_ft4222()
    if not devA:
        return False

    if dis:
        print(f"==== Test BFIC disable all ====")
        dis = 0xF
    else:
        print(f"==== Test BFIC pol:{pol} with com:{com}, ele:{ele} ====")

    if pol == 0:
        en_list.remove(2)
        dis_list.append(2)
        en_list.remove(3)
        dis_list.append(3)
    elif pol == 1:
        en_list.remove(0)
        dis_list.append(0)
        en_list.remove(1)
        dis_list.append(1)

    for type_id in en_list:
        # txh rxh txv rxv
        reg_addr_hex = int.from_bytes(reg_addr_list[type_id], 'big')
        print("En 0x%03X(%d)" %(reg_addr_hex, reg_addr_hex))
        reg_ic = (reg_addr_hex << 48 | dis << 44 | com << 40
                | ele << 36 | ele << 32 | ele << 28 | ele << 24)

        for chain_id in range(len(header_list)):
            # for each chain
            header = header_list[chain_id]
            pattern = bytearray(header)
            for ic_pair in range(2):
                phase_hex = int.from_bytes(phase_list[type_id][chain_id][ic_pair*2], 'big')
                reg_hex = reg_ic | phase_hex

                phase_hex = int.from_bytes(phase_list[type_id][chain_id][ic_pair*2+1], 'big')
                reg_hex = reg_hex << 60 | reg_ic | phase_hex

                reg_bytes = reg_hex.to_bytes(15, 'big')
                pattern += bytearray(reg_bytes)
            spi_transfer(devA, devB, pattern)

    for type_id in dis_list:
        # txh rxh txv rxv
        dis = 0xF
        reg_addr_hex = int.from_bytes(reg_addr_list[type_id], 'big')
        print("Dis 0x%03X(%d)" %(reg_addr_hex, reg_addr_hex))
        reg_ic = (reg_addr_hex << 48 | 0xF << 44)

        for chain_id in range(len(header_list)):
            # for each chain
            header = header_list[chain_id]
            pattern = bytearray(header)
            for ic_pair in range(2):
                reg_hex = reg_ic << 60 | reg_ic

                reg_bytes = reg_hex.to_bytes(15, 'big')
                pattern += bytearray(reg_bytes)
            spi_transfer(devA, devB, pattern)

    close_ft4222(devA, devB)
    return True

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    control_group = parser.add_argument_group(title="Control cmds")
    control_group.add_argument("--dis", help="Disable all ICs", type=bool, default=False)
    control_group.add_argument("--pol", help="Polorization(0:H,1:V,2:H+V), default:2", type=int, default=2)
    control_group.add_argument("--com", help="T/R att com gain step(0-15), default:15", type=int, default=15)
    control_group.add_argument("--ele", help="T/R att ele gain step(0-15), default:15", type=int, default=15)
    parser.add_argument("--get", help="Get reg info with for the assigned reg", type=hex_int_type)
    args = parser.parse_args()

    devA, devB = initialize_ft4222()

    if devA:
        if args.get is not None:
            for chain_id in range(len(header_list)):
                print(f"Chain-{chain_id+1}")
                # for each chain
                # RADDR
                raddr = 0x03D << 48 | args.get & 0x3FF
                raddr = raddr << 60 | raddr
                raddr_bytes = raddr.to_bytes(15, 'big')
                pattern = bytearray(header_list[chain_id]) + bytearray(raddr_bytes) + bytearray(raddr_bytes)
                spi_transfer(devA, devB, pattern)

                # SPARE
                spare = 0x001 << 48
                spare = spare << 60 | spare
                spare_bytes = spare.to_bytes(15, 'big')
                pattern = bytearray(header_list[chain_id]) + bytearray(spare_bytes) + bytearray(spare_bytes)
                spi_transfer(devA, devB, pattern)
        else:
            if args.dis:
                print(f"==== Test BFIC disable all ====")
                dis = 0xF
            else:
                print(f"==== Test BFIC pol:{args.pol} with com:{args.com}, ele:{args.ele} ====")

            if args.pol == 0:
                en_list.remove(2)
                dis_list.append(2)
                en_list.remove(3)
                dis_list.append(3)
            elif args.pol == 1:
                en_list.remove(0)
                dis_list.append(0)
                en_list.remove(1)
                dis_list.append(1)

            for type_id in en_list:
                # txh rxh txv rxv
                reg_addr_hex = int.from_bytes(reg_addr_list[type_id], 'big')
                print("En 0x%03X(%d)" %(reg_addr_hex, reg_addr_hex))
                reg_ic = (reg_addr_hex << 48 | dis << 44 | args.com << 40
                        | args.ele << 36 | args.ele << 32 | args.ele << 28 | args.ele << 24)

                for chain_id in range(len(header_list)):
                    # for each chain
                    header = header_list[chain_id]
                    pattern = bytearray(header)
                    for ic_pair in range(2):
                        phase_hex = int.from_bytes(phase_list[type_id][chain_id][ic_pair*2], 'big')
                        reg_hex = reg_ic | phase_hex

                        phase_hex = int.from_bytes(phase_list[type_id][chain_id][ic_pair*2+1], 'big')
                        reg_hex = reg_hex << 60 | reg_ic | phase_hex

                        reg_bytes = reg_hex.to_bytes(15, 'big')
                        pattern += bytearray(reg_bytes)
                    spi_transfer(devA, devB, pattern)

            for type_id in dis_list:
                # txh rxh txv rxv
                dis = 0xF
                reg_addr_hex = int.from_bytes(reg_addr_list[type_id], 'big')
                print("Dis 0x%03X(%d)" %(reg_addr_hex, reg_addr_hex))
                reg_ic = (reg_addr_hex << 48 | 0xF << 44)

                for chain_id in range(len(header_list)):
                    # for each chain
                    header = header_list[chain_id]
                    pattern = bytearray(header)
                    for ic_pair in range(2):
                        reg_hex = reg_ic << 60 | reg_ic

                        reg_bytes = reg_hex.to_bytes(15, 'big')
                        pattern += bytearray(reg_bytes)
                    spi_transfer(devA, devB, pattern)

    close_ft4222(devA, devB)