import argparse
from ftdi_spi_sender import *

header = [0xF0, 0x05]
reg_addr = [0x00, 0x1E]
reg_data = [0x00, 0x00, 0x00, 0x00, 0x00, 0x00]

def hex_int_type(value):
    try:
        ret = 0
        if value.startswith("0x"):
            ret = int(value, 16)
        else:
            ret = int(value)
        print("\'%s\' -> hex(int): 0x%03X(%d)" %(value, ret, ret))
        return ret
    except ValueError:
        raise argparse.ArgumentTypeError(f"Invalid hex value: {value}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    control_group = parser.add_argument_group(title="Control cmds")
    control_group.add_argument("--att_tx", help="Tx att gain step(0-255), default:0x22", type=hex_int_type, default=0x22)
    control_group.add_argument("--att_rx", help="Rx att gain step(0-255), default:0x24", type=hex_int_type, default=0x24)
    parser.add_argument("--get", help="Get reg info with for the assigned reg", type=hex_int_type)
    args = parser.parse_args()

    devA, devB = initialize_ft4222()

    if devA:
        if args.get is not None:
            # RADDR
            raddr = 0x009 << 48 | args.get & 0x3FF
            raddr_bytes = raddr.to_bytes(8, 'big')
            pattern = bytearray(header) + bytearray(raddr_bytes)
            spi_transfer(devA, devB, pattern)

            # SPARE
            spare = 0x001 << 48
            spare_bytes = spare.to_bytes(8, 'big')
            pattern = bytearray(header) + bytearray(spare_bytes)
            ret_bytes = spi_transfer(devA, devB, pattern)

            payload = (int.from_bytes(ret_bytes, 'big') & 0xFFFFFFFFFFFF) >> 4
            print("0x%06X" %payload)
            if args.get == 30: #0x01E
                tx = (payload >> 8) & 0xFF
                rx = (payload) & 0xFF
                print("TX: 0x%02X(%d), RX: 0x%02X(%d)" %(tx, tx, rx, rx))
        else:
            print(f"==== Test UDIC ATT_Tx:{args.att_tx}, ATT_Rx:{args.att_rx}, ====")
            reg_data[2] = args.att_tx
            reg_data[3] = args.att_rx
            reg_data[4] = args.att_tx
            reg_data[5] = args.att_rx
            pattern = bytearray(header)+bytearray(reg_addr)+bytearray(reg_data)
            spi_transfer(devA, devB, pattern)

    close_ft4222(devA, devB)